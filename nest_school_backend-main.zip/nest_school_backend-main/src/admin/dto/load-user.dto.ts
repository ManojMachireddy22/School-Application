import { ApiProperty } from '@nestjs/swagger';

export class LoadUserDto {
  // Empty DTO since we'll get email from token
} 