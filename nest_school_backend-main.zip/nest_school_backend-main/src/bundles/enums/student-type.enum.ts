export enum StudentType {
  NEW = 'New',
  EXISTING = 'Existing',
  BOARDING = 'Boarding'
} 