import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DataSource } from 'typeorm';
import { HttpService } from '@nestjs/axios';
import { firstValueFrom } from 'rxjs';

import { Payment, PaymentStatus } from './entities/payment.entity';
import { Order, OrderStatus } from '../orders/entities/order.entity';
import { PaymentEventDto } from './dto/payment-event.dto';
import { PaymentClosedDto } from './dto/payment-closed.dto';
import { GetPaymentConfigDto } from './dto/get-payment-config.dto';
import { Cart } from '../cart/entities/cart.entity';
import { CartItem } from '../cart/entities/cart-item.entity';
import { OrderItem } from 'src/orders/entities/order-item.entity';

@Injectable()
export class PaymentService {
  private readonly logger = new Logger(PaymentService.name);

  constructor(
    @InjectRepository(Payment) private payRepo: Repository<Payment>,
    @InjectRepository(Order) private orderRepo: Repository<Order>,
    @InjectRepository(OrderItem) private orderItemRepo: Repository<OrderItem>,
    private ds: DataSource,
    private http: HttpService,
  ) {}

  async getConfig(orderId: string): Promise<GetPaymentConfigDto> {
    const order = await this.orderRepo.findOne({
      where: { id: orderId },
      relations: ['parent'],
    });
    if (!order) throw new NotFoundException(`Order ${orderId} not found`);

    if (!order.parent.parentName)
      throw new NotFoundException(`Parent details not found`);

    const orderItems = await this.orderItemRepo.findOne({
      where: { orderId: Number(order.id) },
      relations: ['student'],
    });

    if (!orderItems.student || !orderItems.student.usid) {
      throw new NotFoundException('No student USID found for this parent');
    }

    return {
      env: process.env.GQ_ENV,
      auth: {
        client_id: process.env.GQ_CLIENT_ID,
        client_secret: process.env.GQ_CLIENT_SECRET,
        api_key: process.env.GQ_API_KEY,
      },
      student_id: orderItems.student.usid,
      application_code: orderId,
      student_details: {
        student_first_name: orderItems.student.studentName,
      },
      customer_details: {
        customer_first_name: order.parent.parentName,
        customer_email: `${orderItems.student.usid}@grayquest.com`,
      },
      fee_headers: {
        current_payable: order.totalPrice,
      },
      pp_config: { slug: process.env.GQ_SDK_SLUG },
    };
  }

  async markPaid(evt: PaymentEventDto) {
    const qr = this.ds.createQueryRunner();
    await qr.connect();
    await qr.startTransaction();
    try {
      const pay = (await qr.manager.findOne(Payment, {
        where: { order: { id: evt.order_code } },
        relations: ['order'],
      })) as Payment;
      if (!pay) throw new NotFoundException(`Payment ${evt.order_code}`);

      pay.status = PaymentStatus.PAID;
      pay.externalReference = evt.bank_reference_id;
      pay.raw = evt;
      pay.applicationCode = evt.application_code;
      await qr.manager.save(pay);

      pay.order.status = OrderStatus.PAID;
      await qr.manager.save(pay.order);

      // Clear the cart after successful payment
      const cart = await qr.manager.findOne(Cart, {
        where: { parentId: pay.order.parentId },
      });
      if (cart) {
        await qr.manager.delete(CartItem, { cartId: cart.id });
      }

      await qr.commitTransaction();
      return { success: true };
    } catch (err) {
      await qr.rollbackTransaction();
      this.logger.error('markPaid failed', err.stack);
      throw err;
    } finally {
      await qr.release();
    }
  }

  async markFailed(evt: PaymentEventDto) {
    const qr = this.ds.createQueryRunner();
    await qr.connect();
    await qr.startTransaction();
    try {
      const pay = await qr.manager.findOne(Payment, {
        where: { order: { id: evt.order_code } },
        relations: ['order'],
      });
      if (!pay) throw new NotFoundException(`Payment ${evt.order_code}`);

      pay.status = PaymentStatus.FAILED;
      pay.raw = evt;
      await qr.manager.save(pay);

      pay.order.status = OrderStatus.FAILED;
      await qr.manager.save(pay.order);

      await qr.commitTransaction();
      return { success: false };
    } catch (err) {
      await qr.rollbackTransaction();
      this.logger.error('markFailed failed', err.stack);
      throw err;
    } finally {
      await qr.release();
    }
  }

  async markClosed(evt: PaymentClosedDto) {
    const qr = this.ds.createQueryRunner();
    await qr.connect();
    await qr.startTransaction();
    try {
      const pay = await qr.manager.findOne(Payment, {
        where: { order: { id: evt.order_code } },
        relations: ['order'],
      });
      if (!pay) throw new NotFoundException(`Payment ${evt.order_code}`);

      pay.status = PaymentStatus.FAILED;
      pay.raw = evt;
      pay.event = evt.event;
      await qr.manager.save(pay);

      pay.order.status = OrderStatus.FAILED;
      await qr.manager.save(pay.order);

      await qr.commitTransaction();
      return { success: true };
    } catch (err) {
      await qr.rollbackTransaction();
      this.logger.error('markClosed failed', err.stack);
      throw err;
    } finally {
      await qr.release();
    }
  }
}
